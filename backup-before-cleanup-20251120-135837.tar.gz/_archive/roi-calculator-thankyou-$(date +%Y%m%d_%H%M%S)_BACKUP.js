$(cat '/Users/robertkowalski/Documents/bimtakeoff-website/js/roi-calculator-thankyou.js')
